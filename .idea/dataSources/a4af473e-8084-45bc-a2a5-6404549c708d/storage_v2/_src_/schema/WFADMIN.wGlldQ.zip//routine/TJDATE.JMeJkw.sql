create function tjDate(ts in Number) return date is
  FunctionResult date;
begin
  FunctionResult := to_date(to_char(TRUNC(SYSDATE-ts),'yyyy-mm-dd') || 
	'17:00:00','yyyy-mm-dd hh24:mi:ss');
   return(FunctionResult);
end tjDate;
/

